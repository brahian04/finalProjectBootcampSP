package com.Brahian.BdBank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BdBankApplicationTests {

	@Test
	void contextLoads() {
	}

}
