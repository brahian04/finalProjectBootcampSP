package com.Brahian.BdBank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BdBankApplication {

	public static void main(String[] args) {
		SpringApplication.run(BdBankApplication.class, args);
	}

}
